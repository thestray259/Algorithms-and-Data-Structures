﻿using System;

namespace Labs
{
    class Program
    {
        static void Main(string[] args)
        {
            Isomorphics.CreateIsomorphs(); 
            //Console.WriteLine();
        }
    }
}
